define mc = Character("Lucas", color="#00bfff")
define mc_inner = Character("Lucas (Mind)", color="#95a5a6", italic=True)
define stepmom = Character("Diana", color="#da70d6")
define dean = Character("Dean Cassandra", color="#8b0000")
define classmate = Character("Naomi", color="#ff1493")

label start:
    scene bg_intro_dark with fade
    play music "dark_mystery_ambient.mp3" fadein 2.0
    "Ek hafta ho gaya hai... mere dad ki body ko is thandi zameen ke neeche dafnaye hue."
    "Police aayi, unhone formality ki aur kaha ki dad ne depression mein aakar drugs ka overdose kiya aur suicide kar liya... unhone case ek jhatke mein band kar diya."
    "Par main jaanta hoon ye ek bohot bada jhoot hai! Dad koi kamzor insaan nahi the."
    "Wo is shahar ke sabse corrupt, sabse powerful logo ke kaale dhandho ka pardafash karne wale ek fearless Investigative Journalist the."
    "Aur unki maut ke theek baad... hamare hi ghar mein kuch ajeeb hone laga."
    "Diana... meri gorgeous aur young stepmom, jo kal tak dad ke saamne seedhi banti thi, unki maut ke agle hi din se dad ke saare business, bank accounts aur is aalishan mansion par apna kabza jama kar baith gayi."
    "Aur jagah main college gaya, to wahan ki strict aur hot Dean Cassandra ne bina koi thos wajah bataye, dad ke marne ke agle hi din mere scholarship papers reject kar diye... jaise wo dono milkar mujhe is shahar se hamesha ke liye bhagana chahti hon."

    scene bg_mansion_livingroom with flash
    play music "suspense_tension.mp3" fadein 1.0
    "Aaj subah main living room mein khada chupchap soch raha tha, tabhi seedhiyo se diamond heels ki wahi tez aur chubhne wali aawaz gunji... khat... khat... khat..."
    "Diana seedhiyo se neeche aa rahi thi. Silk ki ek bohot hi hot, translucent red nighty pehne hue, jisme se uski curvy body saaf jhalak rahi thi."
    "Dad ke jaane ka koi afsoos ya gham uske chehre par door-door tak nahi tha, balki uski aakhon mein ek ajeeb sa ghamand aur nayi-nayi mili daulat ki chamak thi."

    stepmom "Lucas? Tum abhi tak yahin khade ho? Mujhe laga tum ab tak college ke liye nikal chuke hoge. Ya phir ab tumne poora din is ghar mein baithkar sirf muft ki rotiya todne ka faisla kar liya hai?"
    stepmom "Dekho, main pehle hi saaf kar doon... tumhare dad chale gaye hain, aur ab is itne bade mansion ka maintenance aur kharch uthana aasan nahi hai. Main yahan kisi ka faltu bojh nahi uthaungi."

    mc "Bojh? Diana, ye ghar mere dad ka hai. Aur unhe mare hue abhi ek hafta bhi nahi hua hai, aur tum aisi baatein kar rahi ho?"
    "Diana mere thoda aur kareeb aayi, uske jism se ek mehnge perfume ki tez khushboo aa rahi thi. Usne apni baahein sameti aur mujhe upar se neeche ghoora."

    stepmom "Ghar tumhare dad ka tha, Lucas. Ab unke saare papers aur ye property mere naam par legal ho chuki hai. Isliye agar is ghar mein rehna hai, to chupchap koi part-time naukri dhoondna shuru karo... warna apna boriya-bistar sametho aur bahar ka raasta dekho. Samajh gaye?"

    mc_inner "Ghamandi aurat... iska ye badla hua roop hi bata raha hai ki ye andar se kitni kaali hai. Dad ki maut ke peeche iska aur college ki dean Cassandra ka koi gehra rishta hai. Mujhe bas iske khilaf koi pakka saboot chahiye."
    mc "Chinta mat karo Diana, main chala jaunga. Waise... kal raat main dad ke study room mein unki purani investigation files dhoond raha tha... par wo locker se gayab thi. Tumhe kuch pata hai un files ke baare mein? Kisi ne unhe chhua tha?"

    "Mera ye sawaal sunte hi Diana ke haath mein pakda hua coffee mug halka sa kaampa. Uski aakhon mein ek pal ke liye darr aur ghabrahat saaf dikhi, aur usne turant apni nazrein mujhse chhurayi."
    stepmom "M... Mujhe kya pata hoga? Main kyu tumhare dad ke purane raddi kachre ke dher ko chhungi? Mujhe is faltu ki baato mein koi interest nahi hai... chupchap college niklo aur mera dimaag kharab mat karo!"
    "Wo jhatke se mudi aur apni heels patak te hue tez kadmo se wapas apne bedroom ki taraf chali gayi. Uski is achanak badli hui ghabrahat ne mera shakk 100% yakeen mein badal diya."

    scene bg_lucas_bedroom with dissolve
    "Main chalte hue apne kamre mein aaya aur darwaza halka sa band kar liya."
    "Mansion mein ab ajeeb sa sannata tha. Main akele khada hokar window se bahar dekh raha tha aur mera dimaag tezi se chal raha tha."
    mc_inner "Dad ki maut ka raaz... wo files... sab isi ghar mein hain. Diana mujhse kuch bohot bada chhupa rahi hai."
    "Tabhi mujhe corridor se Diana ke bathroom ka shower chalne ki aawaz aayi."
    mc_inner "Diana abhi nahane gayi hai. Uske bedroom ka darwaza khula reh gaya hai... Yahi sabse sahi mauka hai uske cupboard se locker ki asli chabi churane ka."

    menu:
        "Diana ke bedroom mein chupke se ghuso":
            jump quest_1_start
        "Abhi risk mat lo, seedhe college niklo":
            jump quest_2_start

label quest_1_start:
    scene bg_diana_bedroom with fade
    "Main dabe paaon Diana ke bedroom mein aaya. Bathroom se shower ki aawaz aa rahi thi..."
    "Mera dil tez dhadak raha tha. Agar wo bahar aa gayi to sab khatam ho jayega."
    "Maine cupboard kholi aur wahan mujhe dad ki ek secret file mili, jispar likha tha: 'Cassandra & Naomi - The Asset'."
    mc_inner "Yaani college ki dean aur uski bhanji Naomi... dad inke kisi gande raaz par kaam kar rahe the! Mujhe abhi college nikalna hoga."
    
    "Main secret file apne bag mein chhupa kar dabe paaon mansion se bahar nikal gaya."
    jump college_travel_scene

label quest_2_start:
    "Maine abhi risk lena sahi nahi samjha. Maine apna bag uthaya aur seedhe college ke liye nikal gaya."
    jump college_travel_scene

label college_travel_scene:
    scene black with dissolve
    "Mansion se nikal kar main college ki bus mein baith gaya. Safar ke dauran main bas yahi sochta raha ki dad ki file mein Dean Cassandra aur Naomi ka naam kyu tha."
    "Kuch der baad, bus college ke campus ke samne ruk gayi."
    jump quest_2_main

label quest_2_main:
    scene bg_college_corridor with fade
    play music "college_ambient.mp3" fadein 1.0
    "College ka mahaul hamesha ki tarah normal tha. Sab ameer baap ke bigde bachhe apni luxury cars mein ghoom rahe the."
    "Tabhi samne se Naomi apni friends ke saath aati dikhi. Naomi... is college ki sabse ameer aur arrogant ladki, aur Dean Cassandra ki sagi bhanji."
    "Dad ki file ke mutabik, Dean ke saare kaale dhandho ka hisab isi Naomi ke paas rehta hai."
    
    "Main chupchap wahan se nikla aur library ke computer lab mein apni part-time job khatam karne chala gaya."
    
    scene bg_computer_lab with dissolve
    "Shaam ho chuki thi. Lab puri tarah khali ho chuki thi aur main apna kaam sameth raha tha."
    "Tabhi mujhe corridor se kisi ke rone ki dheemi aawaz sunai di. Aawaz pass ke hi khali professor cabin se aa rahi thi."
    
    scene bg_empty_office with fade
    "Main dabe paaon uske peeche gaya aur khidki se andar jhaanka. Andar jo ho raha tha, uski umeed mujhe bhi nahi thi!"
    "Naomi wahan table par baithkar khali cabin mein chupke se final exam ke papers chura rahi thi, aur apne bag mein drugs ke packets chhupa rahi thi."
    "Maine turant apna phone nikala aur uska pura video record kar liya."
    play sound "camera_shutter.mp3"
    "Darwaze ki aawaz se Naomi chaunk gayi aur usne peeche mudkar mujhe dekha."
    
    naomi "Tum?! Loser Lucas? Bahar niklo yahan se! Teri himmat kaise hui andar aane ki?"
    mc "Chillao mat Naomi... warna pura college yahan ikkhada ho jayega. Aur waise bhi, mere haath mein jo video hai, agar wo social media par chali gayi to..."
    "Maine use phone ki screen dikhai. Video dekhte hi Naomi ka saara ghamand hawa ho gaya. Uska chehra darr se kaanpne laga."
    naomi "Please Lucas! Agar mausi Cassandra ko pata chala to wo mujhe jaan se maar dengi. Please ishe delete kar do, tum jo kahoge main wo karungi!"

    menu:
        "Ushe darao aur apne wash mein karo (SEX SCENE TRIGGER)":
            jump naomi_h_scene
        "Sirf Dean ke cabin ka passcode maango":
            jump naomi_code_route

label naomi_h_scene:
    mc "Jo main kahunga wo karungi? Theek hai... to pehle apne ye kapde utaro."
    
    # 1. PEHLI IMAGE: Kapde utarne wali
    scene h_scene_naomi with fade
    play music "sensual_music.mp3"
    "Naomi ka saara attitude ab floor par bikhra pada tha. Wo bed par puri tarah helpless thi."
    "Kal tak jo queen mujhe keeda samajhti thi, aaj wo bina kapdo ke mere samne kaanp rahi thi."

    mc "Ab pata chala Naomi? Aaj tera poora ghamand main is bed par tujhe nangi karke ch*dunga!"

    # 2. DUSRI IMAGE: Shirt khul kar bed par leetne wali
    scene h_scene_naomi_2 with dissolve
"Wo sharm aur darr se laal hokar bed par mere samne let gayi. Uski aakhon mein aansu the naomi meri baby ro kyu rhi hai abhi to tujhe letaya hai maine baby ro mat ."

    # >>> 🔥 यहाँ से पच-पच वाला साउंड लूप में चालू हो जाएगा! ===
    play sound "wet_sound.mp3" loop

    # 3. TEESRI IMAGE: Pehla intimate doggy style act
    scene h_scene_naomi_3 with dissolve
    naomi nhi lucas please hath jod rhi hu mat karo lucas nhi ....nhi...."Ahhh... Lucas... mat karo... ufff... tum to sach me mere seal tod doge... nahi lucas mat dalo please ahhhh meri chut phat jaegi..."

    # 4. CHAUTHI IMAGE: Uthakar karne wala heavy intimate act
    scene h_scene_naomi_4 with dissolve
    mc "Chillaye ja! Aaj ke baad tera ye attitude mere samne nahi dikhna chahiye, aur tu isi ke layak hai ahhh....teri chut naomi kitni achi kitni tight...ohhh naomi teri chut mai lund dalne mai maja aa rha hai naomi....mai ander teri chut mai mera maal daalne wala hu naomi kyuki tu meri randi banegi aaj ke baad !"

    # 5. PAANCHVI IMAGE: Maal andar daalne wala final climax
    scene h_scene_naomi_5 with dissolve
    "Maine bina koi parwah kiye apna poora gussa aur apna poora maal uske andar hi chhor diya."
    mc "Ye yaad rakhna Naomi, ab se teri har ek cheez par mera kabza hai."
    naomi "Ahhhh lucas tumne meri chut ko phaad diya aur mere ander apna maal daal diya .ohhh....Aaa lucas"

    # माल अंदर डालते ही पच-पच वाला साउंड अपने आप बंद हो जाएगा
    stop sound
    
    "Maine bina koi parwah kiye apna poora gussa aur apna poora maal uske andar hi chhor diya."
    mc "Ye yaad rakhna Naomi, ab se teri har ek cheez par mera kabza hai."
    
    scene bg_empty_office with fade
    "Naomi ke jism aur uski rooh ko poori tarah se corrupt karne ke baad main wapas khada hua."

    mc "Ab suno dhyan se. Mujhe tumhari mausi yani Dean Cassandra ke personal cabin ka passcode chahiye. Abhi ke abhi!"
    naomi "Passcode '0412' hai... please Lucas, ab mujhe jaane do aur wo video delete kar dena."



mc "Wakt aane par kar dunga. Abhi chupchap yahan se niklo."
jump quest_3_start
label naomi_code_route:
mc "Mujhe Dean Cassandra ke personal cabin ka passcode batao, warna video abhi upload ho jayegi."
naomi "Passcode '0412' hai! Please ishe kisi ko mat batana, main barbad ho jaungi."
jump quest_3_start
label quest_3_start:
scene black with fade
"Raat ke 12 baj chuke the... Main black jacket pehne chupke se Dean Cassandra ke cabin ke bahar pahucha."
scene bg_dean_office with fade
"Maine passcode '0412' dala... aur khat se darwaza khul gaya. Kebin ekdum luxury tha."
"Main seedhe unke computer ki taraf badha aur use on kiya. Mujhe wo folder mil gaya: 'The Blueprint'."
"Maine file ko pendrive mein copy karna shuru kiya. Tabhi maine us folder ke andar ki ek video file par click kiya..."
play music "dark_thriller.mp3"
"Video play hote hi screen par jo dikha, usne mere rongte khade kar diye..."
"Video mein meri stepmom Diana aur Dean Cassandra shahar ke mayor ke saath ek dark room mein baithi thi... aur wo dean hanste hue mere dad ki drink mein zeher mila rahi thi!"
mc_inner "To... to dad ne suicide nahi kiya tha! Inono ne milkar dad ka murder kiya tha! Mujhe har haal mein badla lena hoga."
play sound "light_switch.mp3"
"Achanak pure cabin ki lights on ho gayi. Main jhatke se peeche muda."
"Darwaze par Naomi khadi thi! Uske haath mein ek gun thi jo seedhe meri chest par tani hui thi."
naomi "I am sorry Lucas... maine mausi ko bachane ke liye tumhe passcode diya tha taaki tum yahan aao. Tumne bohot aage tak dekh liya. Ab tum yahan se zinda bahar nahi ja sakte."
mc "Naomi! Tum pagal ho gayi ho kya? Tumhari mausi ek murderer hai! Usne mere dad ko maara hai!"
"Naomi ne kaanpte haatho se gun ka trigger dabaya..."
naomi "Mujhe maaf kar dena Lucas..."
play sound "gunshot.mp3"
scene black with flash
stop music
"..."
" Kya Lucas bach payega? "
" Kya wo apne pita ki maut ka badla pura kar payega? "
    "{size=+20}{color=#ff0000}VILE TRUTHS: CHAPTER 1 (COMING SOON){/color}{/size}"
    
    # === 🔥 ये नई लाइन यहाँ जुड़ जाएगी ताकि प्लेयर्स को पता रहे ===
    "Note: Diana and Cassandra's full character visual models will unlock in Chapter 1."
    
    $ MainMenu(confirm=False)()
    return
